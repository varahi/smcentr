-- MariaDB dump 10.19  Distrib 10.4.27-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.27-MariaDB-1:10.4.27+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `answer` longtext NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DADD4A25700047D2` (`ticket_id`),
  KEY `IDX_DADD4A25A76ED395` (`user_id`),
  CONSTRAINT `FK_DADD4A25700047D2` FOREIGN KEY (`ticket_id`) REFERENCES `ticket` (`id`),
  CONSTRAINT `FK_DADD4A25A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
INSERT INTO `answer` VALUES (1,1,24,'выапывапывап','2022-12-09 13:16:36'),(2,4,29,'wqeqwe','2023-05-04 07:57:52');
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (1,'Москва'),(2,'Санкт-Петербург'),(3,'Курск'),(4,'Липецк'),(5,'Белгород'),(6,'Ростов-на-дону'),(7,'Воронеж'),(8,'Омск'),(9,'Томск'),(10,'Хабаровск'),(11,'Владивосток');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `district`
--

DROP TABLE IF EXISTS `district`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `district` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_31C154878BAC62AF` (`city_id`),
  CONSTRAINT `FK_31C154878BAC62AF` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `district`
--

LOCK TABLES `district` WRITE;
/*!40000 ALTER TABLE `district` DISABLE KEYS */;
INSERT INTO `district` VALUES (1,2,'Красносельский район'),(2,2,'Невский'),(3,2,'Выборгский'),(4,2,'Московский'),(5,1,'Академический'),(6,1,'Алексеевский'),(7,1,'Алтуфьевский'),(8,1,'Арбат');
/*!40000 ALTER TABLE `district` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctrine_migration_versions`
--

LOCK TABLES `doctrine_migration_versions` WRITE;
/*!40000 ALTER TABLE `doctrine_migration_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `doctrine_migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `firebase`
--

DROP TABLE IF EXISTS `firebase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `firebase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `hidden` tinyint(1) DEFAULT NULL,
  `token` longtext NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9B400AE9A76ED395` (`user_id`),
  CONSTRAINT `FK_9B400AE9A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `firebase`
--

LOCK TABLES `firebase` WRITE;
/*!40000 ALTER TABLE `firebase` DISABLE KEYS */;
INSERT INTO `firebase` VALUES (1,'2022-11-18 19:06:15',0,'d1gV-GNjYkM:APA91bFELzem7R3X8Lka0zfu2OLShRn5tgsMg6DAUWj87GmeTR7uRsVGslo_-ozYCVvjVsfJMHHgMi-Qpxiar8yyNLRijCb53P-Kn2Pc6ta0LzNSr7RiWmkUpFfVmxfaXPHamVVoATWj',NULL),(2,'2022-11-18 19:20:45',0,'eC6rE7tzx-A:APA91bHK3rfFmkvnJkD1Nv_zen1lP4t8S1aull6Xa8l0HDjmwPz_uLVMtYxzmZZB1CzSpNty6GKpibpU7Xjiv7v6oHqfp0RreR106i2qTMykd8UQcWiivKimqlaOyKs1nTcU0Vh70QAv',NULL),(3,'2022-11-18 19:20:46',0,'dXc3y_HEgDo:APA91bHuJRgMQ6I29N0LFUk9zPRhbytRQi9Cfn9S14-b4VmA8rXlQ0pzQNqJRGRw6e7L7klresXeKMWtnxcpUZpMp0WkXO0CI7A3aGw_RIE2I_pU_uW70rJB7AFfOY_wYmCEA5_likwl',NULL),(4,'2022-11-22 15:11:10',0,'dd23NPTpTkg:APA91bE8n40dxn2_E-ZOJPc5U9cDyRv9LFdeT1zq9jC_jk32ZW7wYmw9e6PuP4L5pTsfklm0Hy7nvGpQ0xLHHs5OozFrnQxJnnesLp2tjOND3KjXf-XIu1CxRY2jEI90WPX_5cp-8WPD',NULL),(5,'2022-12-08 02:24:13',0,'dGAxqLFOe4s:APA91bEcRN-e19FvJUH-b8xblxJqz9pdoyY3KOpvXBuapC24jwYpCQ_hLMkencD_mt15eXiaPaF28h3dCp9VNL3SlVvNxxU9r73wCw9oXoB5kFtbQMOI_w0_fABy9_-HlpC3xkzO3OQ9',NULL),(6,'2022-12-08 18:52:18',0,'cZIXfr-WXwU:APA91bFPG6t5jw4qoFfIraj_tIb5SPukyeXusbeWgGqTe9Fe1PGl2xaLxpwU_SdJkThl3tmR8DfuMOxgXzxg_9QKpGs8u6uMC6E5uZBhly-KRjiOGn2NoCQaFv-6OxmlarH9K-xiELhA',NULL),(7,'2022-12-09 00:33:42',0,'fHlO1e21-eo:APA91bEGFw53tfIOeSEnEQyYf_63hlInZYQEX6NNtTHQsxCLmYUEdnx6R1yXzItmxk3xXAHR1X5SRuZHyFgMWCRTShLLctpQB6eyky39wXimGOsAhfamkF8tK9rOEp6q7LT4vXPni7_j',NULL),(8,'2022-12-09 00:33:56',0,'djPGkCRQNiI:APA91bHTTGfTVmrMS7KtbNzp0rLxmiXWISvycOdMVV2WqqCkNCUIuBwEbwI7p56u2Xxk4xX3KdMTQIXB3jl7dfawWRjHtlx_-SDKdbo8oxxlugvgOTaaF7DE3PWQV9KPNqHlA-CIo6mn',NULL),(9,'2022-12-14 19:43:21',0,'fDJpanSkeFM:APA91bHL1K5shcnS2FIwI5ZR4sQyoWTc2wKaBzJ5pZ-ouxBeUDqfmuloedmKBvcbgqiXhEuVKcOuN0_4TkVpHwNbojanNHogh14jx6_oWKankiiOPgqbuIYMyLmFfi14HqHn9ZKgtYWm',NULL),(10,'2022-12-22 10:29:07',0,'dm4p_sXWIv8:APA91bGd5bv_KjOMgV5XTuvPXH7_OsPiEIfAz14YSAnpERZSKxOXUAglXn4pkhlAI0ZptM6kNj8zyywX2jTUwAzySetnJuOmJ6lguB9Tmv7OOwZoHA0Uu6UxqBPTvqwJ5III6arqsBEP',NULL),(11,'2022-12-22 10:29:10',0,'ciclBrIUrfA:APA91bFb4rRpeIe3cAHgBqHMJXP1zzPjShxXbK4g7mQ7Sywf-t3qqf6ncqlIuOGfOtmAfeEa3D-pJ7smPyqkEd_3ns34tANbk0Go-CRhwSzVsEq7S4_lKfIPrdNWo76n7m8lrWcoj7O1',NULL),(12,'2022-12-22 10:29:12',0,'ciclBrIUrfA:APA91bFb4rRpeIe3cAHgBqHMJXP1zzPjShxXbK4g7mQ7Sywf-t3qqf6ncqlIuOGfOtmAfeEa3D-pJ7smPyqkEd_3ns34tANbk0Go-CRhwSzVsEq7S4_lKfIPrdNWo76n7m8lrWcoj7O1',NULL),(13,'2022-12-22 10:29:14',0,'ciclBrIUrfA:APA91bFb4rRpeIe3cAHgBqHMJXP1zzPjShxXbK4g7mQ7Sywf-t3qqf6ncqlIuOGfOtmAfeEa3D-pJ7smPyqkEd_3ns34tANbk0Go-CRhwSzVsEq7S4_lKfIPrdNWo76n7m8lrWcoj7O1',NULL),(14,'2022-12-28 12:08:02',0,'ciclBrIUrfA:APA91bFb4rRpeIe3cAHgBqHMJXP1zzPjShxXbK4g7mQ7Sywf-t3qqf6ncqlIuOGfOtmAfeEa3D-pJ7smPyqkEd_3ns34tANbk0Go-CRhwSzVsEq7S4_lKfIPrdNWo76n7m8lrWcoj7O1',NULL),(15,'2023-04-10 19:11:36',0,'eNEhxIRicD0:APA91bGOCKyswvmv87BHGRLliH5tFB8lj2gfwN-0DY2lwOPBmbZxYZCjAMj51QXd8cm453GIImPjqrHojjQFeYC_HvByodjW8SvzzPeZlezw2cE2ffkXkssvNuqAzCFxdxiJ0cFS6Tge',50),(16,'2023-04-10 19:11:36',0,'cBltxnMo9eQ:APA91bE5uKE_IT3hY4qQJZgseIWqpLCnZ87XGI5EtTbS036GMJL_UnohfApdatR_nYl1a1KSp2I0GftZ9w8hPB5c7hNf1c840RdZt9r8biaSydz2AeEFXMRuyK1LzwpyWmP9iwafMnOn',50),(17,'2023-04-10 19:11:45',0,'fVLCpZIa5nQ:APA91bG1NwAjALmII9e5sTU5NyS2vjSDi7mCKt6fly-ixMRgRhM6b3VmnDJ8ttI5UACl6334H2rq_6BFHNQB-zInIZWL5KR5pizTcGY9yfnGfgIp5zLD_XZ03AyMBrKEEWUbC4JceI5j',50),(18,'2023-04-10 19:11:45',0,'d_giEAMRAPg:APA91bEiK5YQpRH6575yN0dIBMx6vUkH1sNrNBh7klh59K75v1WBtmi-IYq_9f7c7H2QwWTnETqmN6w4TGuAKHzSEJANIJN18kxey9ioKjG6yXLza1rNlgbXOOfY7GVKwsgJqMT49k9F',50),(19,'2023-04-10 19:11:48',0,'dj6x1zsI36M:APA91bGB1k5pDqe4iLrxQRK0GT5HhwK56MTGY6JX3LfaWqa3nUhz7fCRCVq61bKqxvp8Ipz5vtADHSYtkc48ocuXtnM1095f7K5sW28SazVL_HlSJHaB7wXHAIgz_Z-H20634fBd7YNl',50),(20,'2023-04-10 19:11:48',0,'dct8VMS9yaQ:APA91bGpWb1P-zHTWHtBzrwaGHewnWJR1GMKRlQMQOLK85vIQd7FyU3m70hV9HN8JSwK69lbRCYzFQGt6GibLafejHlJBwNYHcO8yt2WU1X1iEfW9aV9sHnIOR_RXkGONqAy9Iln8hbk',50),(21,'2023-04-10 19:32:22',0,'eI1SPiO4MQA:APA91bGMhEGQen-ZeEr5kPvLpISSEMG-Na1ktUoEo_Rts6nZ6zlTP-Ud7b1Npuxhy0yz1kREiOrRz5pzYUTYkONv749AYr-DngNsz9OmkKAnPygax_ugyigk4hcY8G5MHDKvLJjMhokr',NULL),(22,'2023-04-10 19:32:22',0,'dScB5OMxUcE:APA91bFtpuPl50AYfYx-R5fsoCrM30knEqr170tKnGZfArjHpuLqYlR3F6sjXJULK1OIXmS2RIuTWNunnBySAqqxWSOJFcXbI43Xy57TP2dv3Qt86JoTdl25Q05k8nhfKmGseD3QocNs',NULL),(23,'2023-04-10 19:32:33',0,'ezSybaXk_Qw:APA91bGo9lHvTfw_fun4WW4N-6jULMAqelzN_Trox9OZ9S1zCp1dj-ThxQmItHty7lyYvz48v9Onc-epYeCKzqmdEOWaSh3bBaiRlAViryom9mUu-eZagylw685Q5knJTibNN5UmEUos',NULL),(24,'2023-04-10 19:32:33',0,'fP5uk_iGbWk:APA91bG92cSLC2T3TRqDOaWtK3gBodakB7BHjyb_QjNF0VprWATr6y4Xu5pS-TQbVpQjcp9zKlN4-IvPgSdRGt_nYTHFBV7BJSU_4jfpE806Vy9GPGPIFxxwC8ev5I4oBjCqSRIGMUOF',NULL),(25,'2023-04-10 19:49:09',0,'dBCjx1nBZVg:APA91bGKbWEunrJ350gpQzVQ2w_Gv1VtvTutdImmHh7U4wGfCtAZULzMVzK7eMVEwlWNz1QdQUsHWG-WjhArBPMbqt56jxqgQ3rYjGIfsBLqXhnN2ix8_ADvm_wvcynAIvWObj63QNqv',NULL),(26,'2023-04-10 19:49:09',0,'fsXOhmdgyXM:APA91bHa5wlhhk8cIhaYqsmNzwz5zGaj2BwRyyu7lQ8yLSWl-VbRrlR5uuwf8I2UbIye5S3SrfyzMQhtQfaHWgextce7BLmzP5YubFdUDzuXwRAR8PL8GsOdxG1EIE-HNHFGrQnIOSb4',NULL),(27,'2023-04-10 19:49:19',0,'fKKh3_rT_o0:APA91bHFAEx4-FYsJXmTTa5V8eWs40xXEVmDQHoYCKS582s-YLRqeWJ03vtyjxYk5X9g9HRuCceILq5lGC1KrPvdEWC6ts0YXIfQzrlGIo8lLEcmwQ_DcdQQvOOyusgXBEKaH0Glg2lX',NULL),(28,'2023-04-10 19:49:19',0,'eBFQdw2wT0w:APA91bFfvitIanLc3UIzbSTdICf5o_EgTPiipYKZDAqxaOAH1FNcuFwF5sEjjOdhmjTbDpf0S9pxTjFLR2WeJp2hm4qxuaENRL18l6VtLCSCTpCwrjACRXYs0DhiH5ct_wenJT66jtTy',NULL),(29,'2023-04-10 20:30:29',0,'cCr4Yj6sHs4:APA91bE-4LCwtuMGk_SK2UDLz_ligb0oHo3KI8dZeVEclcUXUfCHleS8ALTWlY5b78nvqEsxAnXllfM33S3BghxR5XcMY9kJ0ow44xsmNpr1Yp_MNCuHzSKFm2BgIE7gw8vAcrbDSOJO',NULL),(30,'2023-04-10 20:30:29',0,'cmH2obN8dIQ:APA91bEl1kk9J65254jlJpycHlgz_6-ODRpW7byr-LFqzqsEgFW33oTUYCXI3Htt_Clab1cgYyvtTstUuUXo3yF549K6eWmh7frJomNnemeSiUtdx4e4rzaBAnHWZKjy6_8sKw8zI0dQ',NULL),(31,'2023-04-10 20:30:35',0,'f81gl1gguro:APA91bEXiFJXxkUnAfrhBd-K7aaojJRNtk_klZTpmWuc76PtTDN3gY2q0uWlKH5lYxuOWHHic8cGjcSD-xN8p3TnVyIGDI5T3Tf-qA_wOYgsPJDUwOZrwPfqHcgWYhZ2IYTYG-Iml8yD',50),(32,'2023-04-10 20:30:35',0,'fKXBYcpSMbs:APA91bF-6T91UJZLTU3j2Gu0igMQWGvO_73ZD6nIhFl1UkPZfz62o7UZI4xr5zpAh45dCGX50adATTfEwCno7ZlECoxvoIq_FpQuq_WmehiaVU25BZ_QVFl8ZUmc8b1h5PKPJfztdbsT',50),(33,'2023-04-10 20:31:45',0,'fmFaG3vq9Rc:APA91bEmFk8cRK8beN74HrsRWpPCRAw9K4zQtyaX3OuVsEWGX8ZBWiUhyuYgSXACNTuqiiKS0-WeDKhJCc7lMbqMhTs-brf-u83IhDAmvS1JLmiyrqt5vbfzq5dyxjVth8O5Ii53TLFH',NULL),(34,'2023-04-10 20:31:45',0,'fuUQmQYLq_k:APA91bHYDsRIO-2aeGnCeulxSo21fUez_scEBuJQ3eq7cfwENeHVg93coMVIwvAXX0uSHAuMeT6wDR9dWFNBiqxcSkduCU2odfH1kM9a7-tESXDDfym-2OobanRdQgcCgEHrZAshHPhT',NULL),(35,'2023-04-10 20:31:51',0,'eqQpYHDABNg:APA91bGkjqSw_fKuyl3I59zcw4GbWSvbiTHkSFudbkewjQc7zI4kd9dYgNi6iYkiOpCYQ4bE6fIakpnrmEjdIWNkpHY3fNL4aFntG2UXWB7f7_FhbIFUhvxwDexxu0YmlpAGF9Q5-WRO',NULL),(36,'2023-04-10 20:31:52',0,'eqQpYHDABNg:APA91bGkjqSw_fKuyl3I59zcw4GbWSvbiTHkSFudbkewjQc7zI4kd9dYgNi6iYkiOpCYQ4bE6fIakpnrmEjdIWNkpHY3fNL4aFntG2UXWB7f7_FhbIFUhvxwDexxu0YmlpAGF9Q5-WRO',NULL),(37,'2023-04-10 20:31:52',0,'cE2HZ1ovi8I:APA91bFL80OQvPL09Dn5st_BADHS103AUk5hS1X4SsUV3Pt7BzVZkfUfdbb-LTwafuM8JEXdy6Uw3hEDLRJ7GB0vYzghvTEU_2lLLN31kVu6pDBui0NC_2RJ2fM2vsE1IwKg0q_VqAUi',NULL),(38,'2023-04-10 20:32:54',0,'cE2HZ1ovi8I:APA91bFL80OQvPL09Dn5st_BADHS103AUk5hS1X4SsUV3Pt7BzVZkfUfdbb-LTwafuM8JEXdy6Uw3hEDLRJ7GB0vYzghvTEU_2lLLN31kVu6pDBui0NC_2RJ2fM2vsE1IwKg0q_VqAUi',NULL),(39,'2023-04-10 20:33:15',0,'d6zHY0qqtHI:APA91bEJc421xYwXXhkv9IrGOq9cM_Uk3bgLWUW8Zz_1rcj1zP-blCwTpPPZv5SXShR0zfApEdx8f4llowXLGWY2aVEYZQ902v0RP8pwGiZ4-tA7rEKN9KC794pQOz3WlHqTBVEiwuc_',NULL),(40,'2023-04-10 20:33:16',0,'eAM2aZzgRSg:APA91bENMWl8c-1IuMcbvYM5bFE7mCQFzf9prFAC-0HQKUZSUiJ7oDJxn0EhjBOZgBRHYqVovxduZmihxrt1lAapucF7IqmSUo2FG3Dkuf-AqwG9bGCOyuOgux8U-8U8JNIShKACosm4',NULL),(41,'2023-04-10 20:33:21',0,'eyLyZe3MNEw:APA91bF2DrYc_F3tcWESPS75GwxgKGX9CYwC0ewEcxPppmVLd1-RD7b0lWVPtPiFY0HI12S7xB3wImTXJ9P9Y5HQwHmz21Y5zLn_vsNMg52tFYhz-XXwfflAZK1nhlBHWxIE4WLt2hE0',50),(42,'2023-04-10 20:33:21',0,'c9p-BirTcMQ:APA91bEuEQ9RoCqX4n2Kb48slMl2HPN_kO50Dcxr5F0dpd5ARzDnVNw7WywhpKjf6_8X_CYW10GDrp_cZlR_CYZv6wxDlDHUMp5HS0TgLJERm0plpbNdNjVim3wcCsZvYoyMwQnAQ1GX',50),(43,'2023-04-10 20:35:22',0,'d9Pvl-5OByw:APA91bE9lzeTSREfNFoETRklNl7gLP3t0M9smn8ZULZ7mDoFdKXpoQHqiMaJ1wiOggsDRpg7ngzruTQsJ8LPZtoXBG3QwmSb2W5Gxkc2iB7R9tNjiz-QdFAE7Vn8-zsGpgG-pFxSwgQ8',NULL),(44,'2023-04-10 20:35:22',0,'c4nai2PR32I:APA91bFdgmDR9frMjxOplu1pUV0KtakwrvQQXPxkSGWPQS7V_EsNv677gKDlAaFjWf00PAcSfIQ-a07g6JQdrAzTkKbH88S1Vtp-CajukyrNiFxlo6mPNYu0q4H1vO-FHeJMFhDgJ_2V',NULL),(45,'2023-04-10 20:39:54',0,'dIJGcZueX9U:APA91bEOiHEzvJ6ru1ZudqynWm7jdyOWK8azlorupJDpPESOHwUDQhtZ6_NEbLZzbJztXPJQiv3RO2-X31Mh-hIgqxthSpDtM_QP1nmJGJAFByKngtVRHMx-SVVHS06XHOm1fHMM1Iuw',50),(46,'2023-04-10 20:39:55',0,'cW-BPjFVYfA:APA91bEhTIiS-iwuR6OlvXXMnZ4QpI3gUDLi4z1jFz78ILbYiaeYAicwhlWaf5WfhmUo0sQ-3hAEmKyIN1BFXaUbDeOAteFCigvy6A6ZU4SQpsVpxt_NAhe7Jn_XMcQHC3gCVTpI3Sg-',50),(47,'2023-04-10 20:40:06',0,'dq0ax9Pbvf0:APA91bHeapBxWG5nPaE4XHchEeLPfCnA-zcLG8agSsPXmkU-DXJctfVlst9PlwVR5EaVlL59LMmNK2ytKQHJp4WEs__-PcHajgl-r7xouzNp-ZvS3FgOrGf5aSWj_pWZxH5rSULI0KE2',50),(48,'2023-04-10 20:40:06',0,'cYHE3k8Ri7A:APA91bGVzvM0d0GAraR9Oi38niORRo6Rw4lRY9Wnmequ31hfOWKcatVKnnivMs-GDeHRm4_5jb95Z8DVJNEoFeA23AaQdMR62t-m0nAnVjkOxZayektHU80JOrl7eImiEerdPXCrjFtq',50),(49,'2023-04-10 20:44:19',0,'eoJ7M1gE2Uo:APA91bGfcSOxSZUvMP_Pld_xFvS5zetFaTq2bbPUVbIA0a-bIsO1iBd4rhLg9xBo7XpJ7AHZgSNviCt3cb-AlTRZ-t-YHmfAjkvUreGkClBfNkWx6Msn2rsDviOGAyVRh2wFAv3aNutR',NULL),(50,'2023-04-10 20:44:19',0,'dhLC11OMb_0:APA91bG11Y5LNQAWb6h-brwaqB1ZfAjlCrtBDIhiV8a0BSHpxe6B7hO2Fjj_C3v7Ap003er2upqS-Wt_cCy8a0LD0A_PrTxk2YHdyAzCrg7q5rL7c5JcSmc5lLA5CL9bdzOT6ww3HJK3',NULL),(51,'2023-04-10 20:44:34',0,'e2yxY7Jk_zs:APA91bE8my58aYKx9vSOd55mYpetvFrHhaHD6pDsTuWcGKS23yPOVs0akUhdLYHJu_MrbU54Oq4VxG1Eq6iM_bUXuMj6YxD7GaRlNryK3NvKmmj87q7VYtn-PhcTWHXNnQr5GWh8nZ1c',NULL),(52,'2023-04-10 20:44:34',0,'fJzZPDDcLoE:APA91bFl6PMAxq7HmxleD77kMhvJvpQh5GMx8Mp0OsaG3HFM5PSVHRVpYATuFjxVtD54qi5l3IkK1v6iWWTE76hEg_o8pEeuGWPNgUeGv0hXxOXxHNQpn8TEzGxRZhcbwNhfPlpLWZJX',NULL),(53,'2023-04-10 20:44:44',0,'enjzUHSIDmQ:APA91bEisLYqoNID6kgwPizcsTJVRujWpep1U6L2aFprD8PM4pFpr1QnrWZ4kFvHuIkbCWdlZh8LPGd3mk0uaBPWNfCo5-PDg2lif97vBrAE-FFcCwnH-wHxN0F1rIFPpA-Xs6iFWUzr',NULL),(54,'2023-04-10 20:44:44',0,'fbhmxOwxkfM:APA91bHzo7enNXvG-KSvxbPezpAqBcfzkD-e48HRWuY9Da5gCymymM8tHaBhDpJ-vQQh-ltkJQ_rGE_EkgyzeFSvhUaPSAxaijR80XpoEU11-2pQLSdNswr8SxswLriMejwD0oDQiiDR',NULL),(55,'2023-04-10 20:59:46',0,'dlERtkclpHo:APA91bGJgcDCOyaWV5Oy5HGniGyEqEmba_VUaPyJqnVLgskOa18_Fq1GALfpWw5kSWPPbjr5JtnAth31S7VeYTtRQETMvBMkfoGrcgDR12NvLCJu7Tz2ahqgmoY4KfG567CeNVscIzq9',NULL),(56,'2023-04-10 20:59:46',0,'frh6vECsukk:APA91bHIv6a4nXXxSDFakmP1sp-UUpi3owpEkuV9axrr-odcuxU-ZSTjNtaS3LsWXZs6BX13GjmfD9UagtN3Lv9bHRprdR4w5MHqmM0CupyIhYFSIAcYql7hQYH9rjTfNPJDLbaRRnlo',NULL),(57,'2023-04-10 21:27:15',0,'dteQynJy7SA:APA91bFozSd7vcDrV9s3h_ZMLrO9P_X-VhHbQrJRRLrxJMHCvH3TneM14E-05uZtVYxlx0GDSgDwA2ma9t_1Zg24AmJ0yjKZT17r3vM4E9X86DxWr9blq4S7R_cwmjP6u2qVfAiMDai3',NULL),(58,'2023-04-10 21:27:16',0,'f-kYbvoIJMg:APA91bE8TJv23AH6feIT2giwDSza435G95uvL_4CO2o1JHGeD2t3Ghc2LJhkasN1MdqiFsbccB15309G33F3mgqjA4MEeoGTb41U28URsfRRJMq5hZKT9qGF3bVyPJAbcdIkpRJTao7u',NULL),(59,'2023-04-10 21:27:26',0,'dME9G8T7SD0:APA91bFq4TSAOW1o5Nyp6pKItvmScpIqMC2DmOrWqeIG3R7pSR_rap81whFG1KNhh5VLg0ndI3Ucqhz1p7ZZggdrrSqJufr87FjY58xDgnLdIUxsJHS5voIiUIoVDLHk5NR-eZKI3Bx_',NULL),(60,'2023-04-10 21:27:26',0,'eOdeDUyOvP4:APA91bHYDIxqPiuY69JeURfY1HZDXCeuPgzxVM3hfktkvnQVyvGco1JMyda1kVzoNn8v6iN-cXC1Nm8F3Zdl5zJaax0OYn-hOry50B4B6g-oXi36Ag8FqDgcCo9sH8_mq-Z89x20tLmZ',NULL),(61,'2023-04-10 21:27:37',0,'clSKi8Jm90U:APA91bGEmIjAWx5KDdTNTf8OvNzGTpARKlOdVdeMuEsfW8xJIODCMbntvIQz_D_EiVDRfG2lSRDR-C3J2snLCYzDSA5s6_x_LR3VhF09B4E2k60VBGP9o-HeAurtTSRn5iwuJWb7VjgV',NULL),(62,'2023-04-10 21:27:37',0,'c962ps05SW0:APA91bGuppjXBI65MqAMYC1Mkz-GAsLfGsHyMtLpqODz95ejGncuYpUl4eMUYjEqQ4oM2CEzcJtFG-fAjZoxm30ogvmqkZfYTjxYCQe2_smK4FC6E9J_tlYaranF91m2O_dcE9NxAlDm',NULL);
/*!40000 ALTER TABLE `firebase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_type`
--

DROP TABLE IF EXISTS `job_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `profession_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B122168FDEF8996` (`profession_id`),
  CONSTRAINT `FK_B122168FDEF8996` FOREIGN KEY (`profession_id`) REFERENCES `profession` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_type`
--

LOCK TABLES `job_type` WRITE;
/*!40000 ALTER TABLE `job_type` DISABLE KEYS */;
INSERT INTO `job_type` VALUES (1,'Монтаж розетки',3),(2,'Штроба',3),(3,'Установка счетчика',3),(4,'Замена проводки',3),(5,'Монтаж эл. щитка',3),(6,'Замена труб',NULL),(7,'Устранение поломок',NULL),(8,'Установка крана',2),(9,'Замена крана',2),(10,'Замена планировки',NULL),(11,'Монтаж труб',2),(12,'Монтаж проводки',3),(13,'Монтаж щитка',3),(14,'Монтаж эл. проводки',3),(15,'Монтаж ЛДСПР',3),(16,'Другое',NULL),(17,'Сборка спального гарнитура',4),(18,'Сборка кухни',4),(19,'Сборка камода',4),(20,'Сборка стола',4),(21,'Сборка шкафа',4),(22,'Сборка витрины',4),(23,'Сборка прихожей',4),(24,'Сборка дивана',4),(25,'Сборка кровати',4),(26,'Сборка тумбочки',4),(27,'Монтаж окна',5),(28,'Монтаж балконного блока',5),(29,'Монтаж двери пвх',5),(30,'Монтаж лоджии',5),(31,'Ремонт окон',5),(32,'Монтаж алюминиевой двери',5),(33,'Монтаж витража',5),(34,'Монтаж алюминиевого витража',5),(35,'Монтаж межкомнатной двери',6),(36,'Монтаж входной двери',6),(37,'Ремонт стиральной машины',7),(38,'Ремонт телевизора',7),(39,'Ремонт котла',7),(40,'Ремонт сплит систем',7),(41,'Обслуживание сплит систем',7),(42,'Ремонт компьютера',7),(43,'Ремонт ноутбука',7),(44,'Ремонт микроволновки',7),(45,'Ремонт духового шкафа',7),(46,'Ремонт варочной панели',7),(47,'Ремонт пылесоса',7),(48,'Монтаж сплит системы',8),(49,'Дозаправка сплит системы',8),(50,'Обслуживание сплит системы',8),(51,'Монтаж котла',2),(52,'Монтаж водонагревателя',2),(53,'Монтаж унитаза',2),(54,'Монтаж отопительной системы',2),(55,'Монтаж теплого пола',2),(56,'Монтаж душевой кабинки',2),(57,'Монтаж стиральной машины',2);
/*!40000 ALTER TABLE `job_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messenger_messages`
--

DROP TABLE IF EXISTS `messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  KEY `IDX_75EA56E016BA31DB` (`delivered_at`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `application_id` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `message` varchar(255) NOT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_BF5476CAA76ED395` (`user_id`),
  KEY `IDX_BF5476CA3E030ACD` (`application_id`),
  CONSTRAINT `FK_BF5476CA3E030ACD` FOREIGN KEY (`application_id`) REFERENCES `order` (`id`),
  CONSTRAINT `FK_BF5476CAA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=233 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (19,34,4,'2022-10-30 12:35:52','Вами создана новая заявка',0,'4'),(20,25,4,'2022-10-30 13:03:01','Компания назначила для вас задание',0,'1'),(26,25,7,'2022-11-22 15:57:36','Новая заявка в системе по вашему городу и профессии',0,'4'),(27,11,7,'2022-11-22 15:57:37','Вами создана новая заявка',0,'4'),(28,23,NULL,'2022-12-07 19:52:44','Test message',0,'10'),(29,25,NULL,'2022-12-07 19:52:44','Test message',0,'10'),(31,28,NULL,'2022-12-07 19:54:16','Test message new!!!!',0,'10'),(32,29,NULL,'2022-12-07 19:54:16','Test message new!!!!',0,'10'),(33,34,NULL,'2022-12-07 19:54:16','Test message new!!!!',0,'10'),(34,11,NULL,'2022-12-08 02:25:25','Test message',0,'10'),(35,21,NULL,'2022-12-08 02:25:25','Test message',0,'10'),(36,31,NULL,'2022-12-08 02:25:25','Test message',0,'10'),(37,32,NULL,'2022-12-08 02:25:25','Test message',0,'10'),(38,33,NULL,'2022-12-08 02:25:25','Test message',0,'10'),(39,23,NULL,'2022-12-08 02:25:25','Test message',0,'10'),(40,25,NULL,'2022-12-08 02:25:25','Test message',0,'10'),(42,28,NULL,'2022-12-08 02:25:25','Test message',0,'10'),(43,29,NULL,'2022-12-08 02:25:25','Test message',0,'10'),(44,34,NULL,'2022-12-08 02:25:25','Test message',0,'10'),(45,11,NULL,'2022-12-08 02:25:36','Test message',0,'10'),(46,21,NULL,'2022-12-08 02:25:36','Test message',0,'10'),(47,31,NULL,'2022-12-08 02:25:36','Test message',0,'10'),(48,32,NULL,'2022-12-08 02:25:36','Test message',0,'10'),(49,33,NULL,'2022-12-08 02:25:36','Test message',0,'10'),(50,23,NULL,'2022-12-08 02:25:36','Test message',0,'10'),(51,25,NULL,'2022-12-08 02:25:36','Test message',0,'10'),(53,28,NULL,'2022-12-08 02:25:36','Test message',0,'10'),(54,29,NULL,'2022-12-08 02:25:36','Test message',0,'10'),(55,34,NULL,'2022-12-08 02:25:36','Test message',0,'10'),(56,11,NULL,'2022-12-08 02:25:47','Test message',0,'10'),(57,21,NULL,'2022-12-08 02:25:47','Test message',0,'10'),(58,31,NULL,'2022-12-08 02:25:47','Test message',0,'10'),(59,32,NULL,'2022-12-08 02:25:47','Test message',0,'10'),(60,33,NULL,'2022-12-08 02:25:47','Test message',0,'10'),(61,23,NULL,'2022-12-08 02:25:47','Test message',0,'10'),(62,25,NULL,'2022-12-08 02:25:47','Test message',0,'10'),(64,28,NULL,'2022-12-08 02:25:47','Test message',0,'10'),(65,29,NULL,'2022-12-08 02:25:47','Test message',0,'10'),(66,34,NULL,'2022-12-08 02:25:47','Test message',0,'10'),(67,23,NULL,'2022-12-08 02:25:58','Test message',0,'10'),(68,25,NULL,'2022-12-08 02:25:58','Test message',0,'10'),(70,11,NULL,'2022-12-08 02:26:01','Test message',0,'10'),(71,21,NULL,'2022-12-08 02:26:01','Test message',0,'10'),(72,31,NULL,'2022-12-08 02:26:01','Test message',0,'10'),(73,32,NULL,'2022-12-08 02:26:01','Test message',0,'10'),(74,33,NULL,'2022-12-08 02:26:01','Test message',0,'10'),(75,28,NULL,'2022-12-08 02:26:05','Test message',0,'10'),(76,29,NULL,'2022-12-08 02:26:05','Test message',0,'10'),(77,34,NULL,'2022-12-08 02:26:05','Test message',0,'10'),(78,11,NULL,'2022-12-08 14:02:36','Тестовое сообщение всем пользователям',0,'10'),(79,21,NULL,'2022-12-08 14:02:36','Тестовое сообщение всем пользователям',0,'10'),(80,31,NULL,'2022-12-08 14:02:36','Тестовое сообщение всем пользователям',0,'10'),(81,32,NULL,'2022-12-08 14:02:36','Тестовое сообщение всем пользователям',0,'10'),(82,33,NULL,'2022-12-08 14:02:36','Тестовое сообщение всем пользователям',0,'10'),(83,23,NULL,'2022-12-08 14:02:36','Тестовое сообщение всем пользователям',0,'10'),(84,25,NULL,'2022-12-08 14:02:36','Тестовое сообщение всем пользователям',0,'10'),(86,28,NULL,'2022-12-08 14:02:36','Тестовое сообщение всем пользователям',0,'10'),(87,29,NULL,'2022-12-08 14:02:36','Тестовое сообщение всем пользователям',0,'10'),(88,34,NULL,'2022-12-08 14:02:36','Тестовое сообщение всем пользователям',0,'10'),(89,11,NULL,'2022-12-08 14:11:04','Тестовое уведомление всем пользователям',0,'10'),(90,21,NULL,'2022-12-08 14:11:04','Тестовое уведомление всем пользователям',0,'10'),(91,31,NULL,'2022-12-08 14:11:04','Тестовое уведомление всем пользователям',0,'10'),(92,32,NULL,'2022-12-08 14:11:04','Тестовое уведомление всем пользователям',0,'10'),(93,33,NULL,'2022-12-08 14:11:04','Тестовое уведомление всем пользователям',0,'10'),(94,23,NULL,'2022-12-08 14:11:04','Тестовое уведомление всем пользователям',0,'10'),(95,25,NULL,'2022-12-08 14:11:04','Тестовое уведомление всем пользователям',0,'10'),(97,28,NULL,'2022-12-08 14:11:04','Тестовое уведомление всем пользователям',0,'10'),(98,29,NULL,'2022-12-08 14:11:04','Тестовое уведомление всем пользователям',0,'10'),(99,34,NULL,'2022-12-08 14:11:04','Тестовое уведомление всем пользователям',0,'10'),(100,23,NULL,'2022-12-08 14:11:47','Тестовое уведомление всем мастерам',0,'10'),(101,25,NULL,'2022-12-08 14:11:47','Тестовое уведомление всем мастерам',0,'10'),(103,11,NULL,'2022-12-08 17:59:58','Test',0,'10'),(104,21,NULL,'2022-12-08 17:59:58','Test',0,'10'),(105,31,NULL,'2022-12-08 17:59:58','Test',0,'10'),(106,32,NULL,'2022-12-08 17:59:58','Test',0,'10'),(107,33,NULL,'2022-12-08 17:59:58','Test',0,'10'),(108,23,NULL,'2022-12-08 17:59:58','Test',0,'10'),(109,25,NULL,'2022-12-08 17:59:58','Test',0,'10'),(111,28,NULL,'2022-12-08 17:59:58','Test',0,'10'),(112,29,NULL,'2022-12-08 17:59:58','Test',0,'10'),(113,34,NULL,'2022-12-08 17:59:58','Test',0,'10'),(119,11,7,'2022-12-14 21:45:12','Изменения статуса заявки (закрыта)',0,'1'),(120,25,10,'2022-12-15 11:24:00','Новая заявка в системе по вашему городу и профессии',0,'4'),(121,11,10,'2022-12-15 11:24:02','Вами создана новая заявка',0,'4'),(122,23,10,'2022-12-15 11:28:57','С баланса списано 150 руб. за заявку',0,'3'),(123,23,10,'2022-12-15 11:28:57','Вы взяли заявку',0,'1'),(124,11,10,'2022-12-15 11:28:57','Ваша заявка принята в работу мастером  Мастер на все руки - Дмитрий - mail@mail.ru',0,'1'),(125,23,10,'2022-12-15 12:06:14','С баланса списано 150 руб. за заявку',0,'3'),(126,23,10,'2022-12-15 12:06:14','Вы взяли заявку',0,'1'),(127,11,10,'2022-12-15 12:06:14','Ваша заявка принята в работу мастером  Мастер на все руки - Дмитрий - mail@mail.ru',0,'1'),(128,23,10,'2022-12-15 12:41:57','С баланса списано 150 руб. за заявку',0,'3'),(129,23,10,'2022-12-15 12:41:57','Вы взяли заявку',0,'1'),(130,11,10,'2022-12-15 12:41:57','Ваша заявка принята в работу мастером  Мастер на все руки - Дмитрий - mail@mail.ru',0,'1'),(131,23,10,'2022-12-15 12:44:42','С баланса списано 150 руб. за заявку',0,'3'),(132,23,10,'2022-12-15 12:44:42','Вы взяли заявку',0,'1'),(133,11,10,'2022-12-15 12:44:42','Ваша заявка принята в работу мастером  Мастер на все руки - Дмитрий - mail@mail.ru',0,'1'),(134,23,10,'2022-12-15 12:46:12','Изменения статуса заявки (закрыта)',0,'1'),(135,23,11,'2022-12-15 13:02:07','Новая заявка в системе по вашему городу и профессии',0,'4'),(136,25,11,'2022-12-15 13:02:21','Новая заявка в системе по вашему городу и профессии',0,'4'),(137,34,11,'2022-12-15 13:02:37','Вами создана новая заявка',0,'4'),(138,23,12,'2022-12-21 20:14:49','Новая заявка в системе по вашему городу и профессии',0,'4'),(139,25,12,'2022-12-21 20:14:51','Новая заявка в системе по вашему городу и профессии',0,'4'),(140,11,12,'2022-12-21 20:14:53','Вами создана новая заявка',0,'4'),(141,50,12,'2022-12-21 20:32:09','С баланса списано 100 руб. за заявку',0,'3'),(142,50,12,'2022-12-21 20:32:09','Вы взяли заявку',0,'1'),(143,11,12,'2022-12-21 20:32:09','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(144,50,11,'2022-12-21 20:37:30','С баланса списано 100 руб. за заявку',0,'3'),(145,50,11,'2022-12-21 20:37:30','Вы взяли заявку',0,'1'),(146,34,11,'2022-12-21 20:37:30','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(147,50,9,'2022-12-21 20:48:46','С баланса списано 150 руб. за заявку',0,'3'),(148,50,9,'2022-12-21 20:48:46','Вы взяли заявку',0,'1'),(149,11,9,'2022-12-21 20:48:46','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(150,25,13,'2023-04-08 19:13:07','Новая заявка в системе по вашему городу и профессии',0,'4'),(151,50,13,'2023-04-08 19:13:09','Новая заявка в системе по вашему городу и профессии',0,'4'),(152,11,13,'2023-04-08 19:14:16','Вами создана новая заявка',0,'4'),(153,29,14,'2023-04-09 09:20:44','Вами создана новая заявка',0,'4'),(154,50,10,'2023-04-09 19:35:24','С баланса списано 150 руб. за заявку',0,'3'),(155,50,10,'2023-04-09 19:35:24','Вы взяли заявку',0,'1'),(156,11,10,'2023-04-09 19:35:24','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(157,29,15,'2023-04-13 17:12:59','Вами создана новая заявка',0,'4'),(158,29,16,'2023-04-13 17:14:19','Вами создана новая заявка',0,'4'),(159,25,17,'2023-04-13 17:15:32','Новая заявка в системе по вашему городу и профессии',0,'4'),(160,50,17,'2023-04-13 17:15:44','Новая заявка в системе по вашему городу и профессии',0,'4'),(161,11,17,'2023-04-13 17:16:16','Вами создана новая заявка',0,'4'),(187,50,17,'2023-05-03 17:19:13','Изменения статуса заявки (закрыта)',0,'1'),(188,50,20,'2023-05-03 18:36:24','Новая заявка в системе по вашему городу и профессии',0,'4'),(189,11,20,'2023-05-03 18:37:36','Вами создана новая заявка',0,'4'),(190,50,21,'2023-05-03 18:46:59','Новая заявка в системе по вашему городу и профессии',0,'4'),(191,29,21,'2023-05-03 18:47:05','Вами создана новая заявка',0,'4'),(192,50,21,'2023-05-03 18:48:13','С баланса списано 600 руб. за заявку',0,'3'),(193,50,21,'2023-05-03 18:48:13','Вы взяли заявку',0,'1'),(194,29,21,'2023-05-03 18:48:16','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(195,50,21,'2023-05-03 19:18:31','С баланса списано 600 руб. за заявку',0,'3'),(196,50,21,'2023-05-03 19:18:31','Вы взяли заявку',0,'1'),(197,29,21,'2023-05-03 19:18:34','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(198,50,21,'2023-05-03 19:21:11','С баланса списано 900 руб. за заявку',0,'3'),(199,50,21,'2023-05-03 19:21:11','Вы взяли заявку',0,'1'),(200,29,21,'2023-05-03 19:21:14','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(201,50,21,'2023-05-03 19:23:27','С баланса списано 900 руб. за заявку',0,'3'),(202,50,21,'2023-05-03 19:23:27','Вы взяли заявку',0,'1'),(203,29,21,'2023-05-03 19:23:29','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(204,50,20,'2023-05-03 19:26:08','С баланса списано 500 руб. за заявку',0,'3'),(205,50,20,'2023-05-03 19:26:08','Вы взяли заявку',0,'1'),(206,11,20,'2023-05-03 19:26:11','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(207,50,21,'2023-05-04 18:43:05','Изменения статуса заявки (закрыта)',0,'1'),(208,11,22,'2023-05-06 09:01:45','Вами создана новая заявка',0,'4'),(209,50,16,'2023-05-06 20:03:38','Компания назначила для вас задание',0,'1'),(210,50,20,'2023-05-10 21:08:50','С баланса списано 500 руб. за заявку',0,'3'),(211,50,20,'2023-05-10 21:08:50','Вы взяли заявку',0,'1'),(212,11,20,'2023-05-10 21:08:54','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(213,50,20,'2023-05-10 21:23:27','С баланса списано 500 руб. за заявку',0,'3'),(214,50,20,'2023-05-10 21:23:27','Вы взяли заявку',0,'1'),(215,11,20,'2023-05-10 21:23:30','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(216,50,20,'2023-05-10 21:57:23','С баланса списано 500 руб. за заявку',0,'3'),(217,50,20,'2023-05-10 21:57:23','Вы взяли заявку',0,'1'),(218,11,20,'2023-05-10 21:57:26','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(227,50,20,'2023-05-15 07:17:07','С баланса списано 500 руб. за заявку',0,'3'),(228,50,20,'2023-05-15 07:17:07','Вы взяли заявку',0,'1'),(229,11,20,'2023-05-15 07:17:10','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1'),(230,50,20,'2023-05-15 07:18:19','С баланса списано 500 руб. за заявку',0,'3'),(231,50,20,'2023-05-15 07:18:19','Вы взяли заявку',0,'1'),(232,11,20,'2023-05-15 07:18:23','Ваша заявка принята в работу мастером  Dmitry Vasilev - info@t3dev.ru',0,'1');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) DEFAULT NULL,
  `profession_id` int(11) DEFAULT NULL,
  `job_type_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `price` double NOT NULL,
  `description` longtext DEFAULT NULL,
  `level` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `performer_id` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `closed` datetime DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `estimated_time` longtext DEFAULT NULL,
  `custom_tax_rate` varchar(255) DEFAULT NULL,
  `send_own_masters` tinyint(1) DEFAULT NULL,
  `send_all_masters` tinyint(1) DEFAULT NULL,
  `type_created` varchar(255) DEFAULT NULL,
  `clear_order` tinyint(1) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F529939867B3B43D` (`users_id`),
  KEY `IDX_F5299398FDEF8996` (`profession_id`),
  KEY `IDX_F52993985FA33B08` (`job_type_id`),
  KEY `IDX_F52993988BAC62AF` (`city_id`),
  KEY `IDX_F5299398B08FA272` (`district_id`),
  KEY `IDX_F52993986C6B33F3` (`performer_id`),
  CONSTRAINT `FK_F52993985FA33B08` FOREIGN KEY (`job_type_id`) REFERENCES `job_type` (`id`),
  CONSTRAINT `FK_F529939867B3B43D` FOREIGN KEY (`users_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_F52993986C6B33F3` FOREIGN KEY (`performer_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_F52993988BAC62AF` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`),
  CONSTRAINT `FK_F5299398B08FA272` FOREIGN KEY (`district_id`) REFERENCES `district` (`id`),
  CONSTRAINT `FK_F5299398FDEF8996` FOREIGN KEY (`profession_id`) REFERENCES `profession` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (4,34,2,10,1,6,NULL,3000,NULL,'3','1','+7(879) 500-0022','2022-10-31',25,'2022-10-30 12:35:52',NULL,'Some address',NULL,NULL,0,0,'3',NULL,NULL),(6,11,2,7,1,5,NULL,12321312,'adsdas','3','0','+7(879) 500-0022','2022-11-23',NULL,'2022-11-22 15:57:07',NULL,'пр. Обуховской обороны 87-3',NULL,NULL,NULL,NULL,'1',NULL,NULL),(7,11,2,7,1,5,NULL,12321312,'adsdas','3','9','+7(879) 500-0022','2022-11-23',NULL,'2022-11-22 15:57:36','2022-12-14 21:45:12','пр. Обуховской обороны 87-3',NULL,NULL,NULL,NULL,'1',NULL,NULL),(9,11,3,15,2,2,NULL,3000,NULL,'3','1','+7 (555) 555-5555','2022-12-18',50,'2022-12-15 11:23:04',NULL,'Test address','12-00',NULL,NULL,NULL,'1',NULL,NULL),(10,11,3,15,2,2,NULL,3000,NULL,'2','1','+7 (555) 555-5555','2022-12-18',50,'2022-12-15 11:24:00','2022-12-15 12:46:12','Test address','12-00',NULL,NULL,NULL,'1',NULL,NULL),(11,34,3,4,2,NULL,NULL,2000,'Test order','3','1','+7 (111) 111-1111','2022-12-19',50,'2022-12-15 13:02:07',NULL,'Test address','12',NULL,NULL,NULL,'3',0,1),(12,11,3,4,2,2,NULL,2000,NULL,'3','0','+7 (111) 111-1111','2022-12-26',NULL,'2022-12-21 20:14:49',NULL,'Test address',NULL,NULL,NULL,NULL,'1',0,NULL),(13,11,7,39,2,2,NULL,2500,NULL,'4','0','+7 (111) 222-3333','2023-04-16',NULL,'2023-04-08 19:13:07',NULL,'пр. Обуховской обороны 87-3','12',NULL,NULL,NULL,'1',0,NULL),(14,29,7,39,7,NULL,NULL,3500,NULL,'3','0','+7(879) 500-0022','2023-04-11',25,'2023-04-09 09:20:44',NULL,'Some address',NULL,NULL,NULL,NULL,'3',NULL,NULL),(15,29,7,42,11,NULL,NULL,5000,NULL,'3','0','+7(950) 000-2233','2023-04-09',50,'2023-04-13 17:12:58',NULL,'Some address',NULL,NULL,NULL,NULL,'3',NULL,NULL),(16,29,7,39,7,NULL,NULL,3000,'dfasdasds','5','0','+7(950) 000-2233','2023-04-16',NULL,'2023-04-13 17:14:19',NULL,'qweqweq',NULL,NULL,NULL,NULL,'3',0,5),(17,11,7,39,2,4,NULL,2222,'Информация о заявке','3','9','+7 (950) 000-2233','2023-04-16',50,'2023-04-13 17:15:32','2023-05-03 17:19:13','пр. Обуховской обороны 87-3',NULL,NULL,NULL,NULL,'1',NULL,2),(20,11,7,42,2,2,NULL,5000,NULL,'3','0','+7 (111) 111-1111','2023-05-15',NULL,'2023-05-03 18:36:24',NULL,'Test address','5',NULL,NULL,NULL,'1',0,1),(21,29,7,42,2,2,NULL,6000,NULL,'3','9','+7 (111) 111-1111','2023-05-10',50,'2023-05-03 18:46:59','2023-05-04 18:43:05','Test address','12','300',NULL,NULL,'3',0,NULL),(22,11,7,46,2,NULL,NULL,5000,NULL,'3','0','+7(111) 111-1111','2023-05-25',NULL,'2023-05-06 09:01:45',NULL,'Some address','12',NULL,NULL,NULL,'1',NULL,2),(25,29,7,42,1,2,NULL,5000,'Test info','3','1','+8 (795) 000-0223','2023-05-15',50,'2023-05-11 21:14:43',NULL,'Some address','12','500',NULL,NULL,'3',NULL,NULL),(26,29,7,42,1,2,NULL,5000,'Test info','3','0','87950000223','2023-05-15',50,'2023-05-11 21:24:52',NULL,'Some address','12','500',NULL,NULL,'3',NULL,NULL);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oferta` longtext DEFAULT NULL,
  `privacy` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'<div>\r\n<p><strong>Законодательное определение</strong></p>\r\n\r\n<p>Согласно пункту 1 статьи 435 Гражданского кодекса РФ, офертой признаётся адресованное одному или нескольким конкретным лицам предложение, которое достаточно определённо и выражает намерение лица, сделавшего предложение, считать себя заключившим договор с адресатом, которым будет принято предложение. Оферта должна содержать все существенные условия договора, а также, желательно, иные необходимые для наиболее полного информирования контрагента условия договора.</p>\r\n\r\n<p>Ст. 11 Федерального закона &laquo;О рекламе&raquo; гласит: &laquo;Если в соответствии с Гражданским кодексом Российской Федерации реклама признается офертой, такая оферта действует в течение двух месяцев со дня распространения рекламы при условии, что в ней не указан иной срок&raquo;.</p>\r\n\r\n<p>Во многих европейских странах оферта должна содержать все существенные условия договора (например, в договоре купли-продажи существенным является предмет и цена). В англо-американском праве оферта должна быть не столько определённой, сколько определимой, то есть получатель должен иметь возможность понимать все существенные условия, но сами они могут не оговариваться. Например, цена в оферте может не указываться, и если такая оферта акцептуется, то договор считается заключённым на условиях &laquo;разумной цены&raquo;.</p>\r\n</div>','<div>Политика конфиденциальности<br>Политика конфиденциальности<br>Политика конфиденциальности<br>Политика конфиденциальности<br>Политика конфиденциальности<br>Политика конфиденциальности<br>Политика конфиденциальности<br>Политика конфиденциальности<br>Политика конфиденциальности<br>Политика конфиденциальности<br><br><br></div>');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `amount` double NOT NULL,
  `status` varchar(255) NOT NULL,
  `note` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6D28840DA76ED395` (`user_id`),
  CONSTRAINT `FK_6D28840DA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,58,'Payment from Mater T3dev','2023-04-22 19:40:33',12300,'1',NULL),(2,50,'Payment from Dmitry Vasilev','2023-04-23 09:58:16',100000,'0',NULL);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profession`
--

DROP TABLE IF EXISTS `profession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profession` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `is_hidden` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_BA930D693D8E604F` (`parent`),
  CONSTRAINT `FK_BA930D693D8E604F` FOREIGN KEY (`parent`) REFERENCES `profession` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profession`
--

LOCK TABLES `profession` WRITE;
/*!40000 ALTER TABLE `profession` DISABLE KEYS */;
INSERT INTO `profession` VALUES (2,'Сантехник',NULL,NULL,0),(3,'Электрик',NULL,NULL,0),(4,'Сборщик мебели',NULL,NULL,0),(5,'Монтажник окон',NULL,NULL,0),(6,'Монтажник дверей',NULL,NULL,0),(7,'Мастер по ремонту бытовой техники',NULL,NULL,0),(8,'Монтажник сплит систем',NULL,NULL,0);
/*!40000 ALTER TABLE `profession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES (1,'SMC',NULL,'1000');
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `status` varchar(255) NOT NULL,
  `amount` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_3B978F9FA76ED395` (`user_id`),
  CONSTRAINT `FK_3B978F9FA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request`
--

LOCK TABLES `request` WRITE;
/*!40000 ALTER TABLE `request` DISABLE KEYS */;
INSERT INTO `request` VALUES (1,34,'1 Request from info@rosremont.ru on 10000','2022-11-07 11:14:32','0','10000'),(2,34,'2 Request from info@rosremont.ru on 10000','2022-11-07 13:38:15','0','10000'),(3,29,'3 Request from company@t3dev.ru on 10000','2022-11-17 16:03:28','0','10000'),(4,29,'4 Request from company@t3dev.ru on 1500','2023-05-02 16:21:15','0','1500');
/*!40000 ALTER TABLE `request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reset_password_request`
--

DROP TABLE IF EXISTS `reset_password_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reset_password_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `selector` varchar(20) NOT NULL,
  `hashed_token` varchar(100) NOT NULL,
  `requested_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `expires_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`),
  KEY `IDX_7CE748AA76ED395` (`user_id`),
  CONSTRAINT `FK_7CE748AA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reset_password_request`
--

LOCK TABLES `reset_password_request` WRITE;
/*!40000 ALTER TABLE `reset_password_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `reset_password_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_rate`
--

DROP TABLE IF EXISTS `tax_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tax_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) DEFAULT NULL,
  `profession_id` int(11) DEFAULT NULL,
  `percent` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C36330C18BAC62AF` (`city_id`),
  KEY `IDX_C36330C1FDEF8996` (`profession_id`),
  CONSTRAINT `FK_C36330C18BAC62AF` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`),
  CONSTRAINT `FK_C36330C1FDEF8996` FOREIGN KEY (`profession_id`) REFERENCES `profession` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_rate`
--

LOCK TABLES `tax_rate` WRITE;
/*!40000 ALTER TABLE `tax_rate` DISABLE KEYS */;
INSERT INTO `tax_rate` VALUES (1,1,2,0.1),(2,1,2,0.07),(3,1,3,0.05),(4,2,2,0.1),(5,2,2,0.07),(6,2,3,0.05),(7,2,7,0.1);
/*!40000 ALTER TABLE `tax_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `description` varchar(255) NOT NULL,
  `closed` datetime DEFAULT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_97A0ADA3A76ED395` (`user_id`),
  CONSTRAINT `FK_97A0ADA3A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` VALUES (1,11,'проверка','2022-12-09 13:16:08','проверка',NULL,5,1),(2,50,'Тестовое обращение','2023-04-22 11:28:47','Тестовое обращение',NULL,3,0),(3,58,'Mater T3dev','2023-04-22 19:29:47','Mater T3dev',NULL,3,0),(4,29,'Тестовое обращение от компанииT3Studio','2023-05-02 15:55:43','Тестовое обращение от компанииT3Studio',NULL,3,0);
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(180) NOT NULL,
  `roles` longtext NOT NULL COMMENT '(DC2Type:json)',
  `password` varchar(255) DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `doc1` varchar(255) DEFAULT NULL,
  `doc2` varchar(255) DEFAULT NULL,
  `doc3` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `get_notifications` tinyint(1) NOT NULL,
  `username` varchar(180) DEFAULT NULL,
  `created` datetime NOT NULL,
  `is_disabled` tinyint(1) DEFAULT NULL,
  `tax_rate` double DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `master_id` int(11) DEFAULT NULL,
  `service_tax_rate` double DEFAULT NULL,
  `responsible_person_full_name` varchar(255) DEFAULT NULL,
  `responsible_person_phone` varchar(255) DEFAULT NULL,
  `responsible_person_email` varchar(255) DEFAULT NULL,
  `inn` varchar(255) DEFAULT NULL,
  `ogrn` varchar(255) DEFAULT NULL,
  `checking_account` varchar(255) DEFAULT NULL,
  `bank` longtext DEFAULT NULL,
  `legal_address` longtext DEFAULT NULL,
  `physical_adress` longtext DEFAULT NULL,
  `card_number` varchar(255) DEFAULT NULL,
  `card_full_name` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`),
  KEY `IDX_8D93D6498BAC62AF` (`city_id`),
  KEY `IDX_8D93D649B08FA272` (`district_id`),
  KEY `IDX_8D93D64919EB6921` (`client_id`),
  KEY `IDX_8D93D64913B3DB11` (`master_id`),
  CONSTRAINT `FK_8D93D64913B3DB11` FOREIGN KEY (`master_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_8D93D64919EB6921` FOREIGN KEY (`client_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_8D93D6498BAC62AF` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`),
  CONSTRAINT `FK_8D93D649B08FA272` FOREIGN KEY (`district_id`) REFERENCES `district` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (11,'dmitry@t3dev.ru','[\"ROLE_CLIENT\"]','$2y$13$XMX5nkZbBDqNkKmAWmbBJu0FY7Z2ql6Su5CGYUBJuqgiyDs6BHx6a',1,NULL,NULL,'Васильев Дмитрий Сергеевич','pole-dozhd-tuchi-pejzazh.jpg','+7(950) 001-8515',NULL,NULL,NULL,NULL,2,1,'dmitry@t3dev.ru','2022-08-26 17:46:16',0,NULL,2,29,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,'info@info.ru','[\"ROLE_CLIENT\"]','$2y$13$NWmcBkXGWbbxpy.4ofRvHOfG9Lx7zMoKW6Rqv4puLOMpj.yPssJVS',1,NULL,NULL,'Main Info','735507-main-636ff65f0fcf4.jpg','777',NULL,NULL,NULL,NULL,1,0,'info@info.ru','2022-08-26 17:46:16',0,NULL,8,29,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,'mail@mail.ru','[\"ROLE_MASTER\"]','$2y$13$IE7O60LdzfP1kGBjwVW0JuuZU9nxSitKF2qZgsyJHpn1UK04X5B8e',1,NULL,NULL,'Мастер на все руки - Дмитрий','001-6306182a368e5.jpg','+7950111111','002-6306182a36b9c.jpg','003-6306182a36d2c.jpg','dv-6306182a36e8c.jpg','150',2,1,'mail@mail.ru','2022-08-26 17:46:16',0,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,'admin@smcentr.su','[\"ROLE_SUPER_ADMIN\",\"ROLE_EDITOR\",\"ROLE_SUPPORT\"]','$2y$13$NJoNk5tzwX4iFNOpA8/NHO8c86lzJyePeZ72yV2Q15kJYKONypuGy',1,NULL,NULL,'Admin',NULL,'+7(950) 001-8515',NULL,NULL,NULL,NULL,1,0,'admin@smcentr.su','2022-08-26 17:46:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,'3dway@mail.ru','[\"ROLE_MASTER\"]','$2y$13$dwTm5HNB2xnlJ5hUlc8UpOErJwfRi5LlW..O9HL5g1hPCi7ts5qg.',1,NULL,NULL,'Мастер Электрик',NULL,'+7(965) 075-9955','IMG-20180511-101613-63090892a06fd.jpg','IMG-20180515-165702-63090892a2f1d.jpg','IMG-20180603-092257-63090892a5512.jpg','11669',2,1,'3dway@mail.ru','2022-08-26 17:53:21',0,NULL,2,NULL,29,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3'),(27,'admin2@smcentr.su','[\"ROLE_EDITOR\",\"ROLE_SUPPORT\"]','$2y$13$MVqmyZ7/G59f8Qo7GOIGsedNO4SrAZ5pMvCLn7mVkgpWKo55.ZHim',1,NULL,NULL,'Admin 2',NULL,'+7(111) 222-3333',NULL,NULL,NULL,NULL,2,0,'admin2@smcentr.su','2022-09-02 15:08:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,'company@smcentr.su','[\"ROLE_COMPANY\"]','$2y$13$8bXsGtpxLy8za8Gc2MFoYOjL4QyQJJ2FbFjFraqCp8Glbo9uL4FD6',1,NULL,NULL,'Company name','QI0j1Q9TbXU-63763b5a98aff.jpg','+7(111) 111-1111',NULL,NULL,NULL,NULL,2,0,'company@smcentr.su','2022-09-02 19:16:29',0,NULL,NULL,NULL,NULL,NULL,'Contact Person','+7(111) 222-3333','info@conact.person',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,'company@t3dev.ru','[\"ROLE_COMPANY\"]','$2y$13$H7lSXqenX9J2/oOVbcLMn.jEyWZaiMRYbzBEaw4vtZqbKi7kI20.a',1,NULL,NULL,'T3Studio!!!','g0UEDezlHmE-637641d733f73.jpg','+7(111) 111-1111',NULL,NULL,NULL,'1500',2,1,'company@t3dev.ru','2022-09-02 19:23:37',0,NULL,NULL,55,56,0.1,'Contact Person','+7(111) 222-3333','info@contact.ru',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,'admin3@smcentr.su','[\"ROLE_SUPPORT\"]','$2y$13$p3ecT01WKSxUlDVWoUxBVerGrdFz2TOxK0XaKq4BUfHlvkTWMXzOm',1,NULL,NULL,'Admin 3',NULL,'+7(222) 222-2222',NULL,NULL,NULL,NULL,1,0,'admin3@smcentr.su','2022-09-21 14:34:47',0,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,'robonetika@yandex.ru','[\"ROLE_CLIENT\"]','$2y$13$vjKnIE40uiiep7Jx4mtb/eMOb92mxT1wCx9/yKvkoCEeXrSOGoTL.',1,NULL,NULL,'Иванов','tiger-633ff0d6ba242.jpg','+7(999) 999-9999',NULL,NULL,NULL,NULL,1,0,'robonetika@yandex.ru','2022-10-07 12:26:46',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(32,'varahi@yandex.ru','[\"ROLE_CLIENT\"]','$2y$13$YqfKZeKVw2mmlWggQ9w1kOWW9e3CdUJZaR6yaGuY0COYvIWATd0Gi',1,NULL,NULL,'Test account Varahi','XYn5-4UAtrQ-633ffc9fa9c5b.jpg','+7(950) 001-8515',NULL,NULL,NULL,NULL,2,0,'varahi@yandex.ru','2022-10-07 13:17:03',NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33,'robonetika@gmail.com','[\"ROLE_CLIENT\"]','$2y$13$Tjn/XWOvc0cg9uXrsqFRPO9w17S61vm8AEmpcMPJ3tm0kDGkCkqfS',1,NULL,NULL,'Иванов Иван Иванович','tiger-63404330c4626.jpg','+7(999) 999-9999',NULL,NULL,NULL,NULL,1,1,'robonetika@gmail.com','2022-10-07 18:18:08',NULL,NULL,1,28,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(34,'info@rosremont.ru','[\"ROLE_COMPANY\"]','$2y$13$FHAF/GeMbsJNrVpkW00EMemJKIAtKF58oTXYyi/ZYfWhpP/uNI28u',1,NULL,NULL,'РосРемонт','008-6357d2b4c168f.jpg',NULL,NULL,NULL,NULL,'10000',2,1,'info@rosremont.ru','2022-10-25 12:12:36',0,NULL,NULL,NULL,NULL,0.05,'Зайцев Михаил Романович','+7(923) 123-4567','zaycev@rosremont.ru','111222333','555','777888999','Сельхоз Банк',NULL,NULL,NULL,NULL,NULL),(39,'info@noproblem.ru','[\"ROLE_CLIENT\"]','$2y$13$YTf888ct3fFEHf79WfEPvOZ83ME4bU.rsheZio9aGWT06OvqBdNRu',1,NULL,NULL,'Test','gHXw21kCnuY-6392095be6486.jpg','+7(111) 223-3444',NULL,NULL,NULL,NULL,1,0,'info@noproblem.ru','2022-12-08 18:53:36',NULL,NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(44,'sudo@smcentr.su','[\"ROLE_SUPER_ADMIN\",\"ROLE_EDITOR\",\"ROLE_SUPPORT\"]','$2y$13$KriYh3cocoWpi.mR0S0h/uQdluAK1sDm3hrPCyukYaz4Esd7xC97K',1,NULL,NULL,'Dmitry','img_02_650x650_46b.jpg',NULL,NULL,NULL,NULL,NULL,NULL,0,'sudo@smcentr.su','2022-12-11 19:39:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(47,'master@mail.ru','[\"ROLE_MASTER\"]','$2y$13$y58c0aeVL6.IYFQdl3xQn.qpdcv8P4pHaPrOYv1kdRgzFMt81fR5S',0,NULL,NULL,'Master Mail',NULL,NULL,NULL,NULL,NULL,NULL,1,0,NULL,'2022-12-14 19:40:02',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(50,'info@t3dev.ru','[\"ROLE_MASTER\"]','$2y$13$oLVLY4l814eRqK4YdxAfkOUL6fJJ9.6opJwtN8EatTXlLTzY2Xdl6',1,NULL,NULL,'Dmitry Vasilev','img-02-650x650-46b-63a2ca581dad0.jpg','+7(950) 001-8515',NULL,NULL,NULL,'5000',2,1,'info@t3dev.ru','2022-12-21 08:53:40',0,NULL,2,NULL,29,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'4'),(51,'info33@t3dev.ru','[\"ROLE_MASTER\"]','$2y$13$fmZY/bTwqRqG0L5idLUlEuCiRvQw2On8QYlZL/z5g333y8yUSh19W',0,NULL,NULL,'Dmitry Vasilev',NULL,'+7(879) 500-0022',NULL,NULL,NULL,NULL,4,0,'info33@t3dev.ru','2023-01-16 20:53:42',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3'),(52,'info34@t3dev.ru','[\"ROLE_CLIENT\"]','$2y$13$PWIffsc9qBjqhbgmu.EyBONrT4.XsF/d70SP7.vaIp0HxbHk06Iii',1,NULL,NULL,'Дмитрий Васильев',NULL,'+7(111) 222-3344',NULL,NULL,NULL,NULL,11,0,'info34@t3dev.ru','2023-01-16 21:03:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(53,'info44@mail.ru','[\"ROLE_MASTER\"]','$2y$13$xFfDcHKDdrcxyQb41TwU/OG.uUfIXYb.HCUqFmTDc33emsbWb31YC',0,NULL,NULL,'Vasilev Dmitry!!',NULL,'+7(950) 001-8515',NULL,NULL,NULL,NULL,11,0,'info44@mail.ru','2023-04-08 16:51:11',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(54,'test333@t3dev.ru','[\"ROLE_MASTER\"]','$2y$13$CYajUeq4UBOJX1KSb1IU9.CevBp/DUcBkAp/aK4FyIwNwSLar/Fua',0,NULL,NULL,'Ольга Нечаева',NULL,'+7(950) 000-2233',NULL,NULL,NULL,NULL,1,0,'test333@t3dev.ru','2023-04-09 10:09:46',0,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(55,'client1111@t3dev.ru','[\"ROLE_CLIENT\"]','$2y$13$W.9qaFWquhJ.pBEU.g1ZYeqLimOH/uGSK4yqU00KRtYrLpEViUXpG',1,NULL,NULL,'Dmitry Vasilev',NULL,'+7(879) 500-0022',NULL,NULL,NULL,NULL,1,0,'client1111@t3dev.ru','2023-04-09 10:28:16',NULL,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(56,'master222@t3dev.ru','[\"ROLE_MASTER\"]','$2y$13$P0sHXVBM2M.0vzqFMl7XqOXDSLS9GtS/SXu5z3QO1qSHoRzWLf/e.',0,NULL,NULL,'Dmitry Vasilev',NULL,'+7(879) 500-0022',NULL,NULL,NULL,NULL,1,0,'master222@t3dev.ru','2023-04-09 10:28:55',0,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(57,'info333@t3dev.ru','[\"ROLE_MASTER\"]','$2y$13$5njJTVJNT4VXomNjC7VuBuATUvzy/LT2RlXhDZSuJIOecxu99t9Iq',0,NULL,NULL,'Ольга Нечаева','735507-main-6436eaf43993e.jpg','+7(950) 000-2233',NULL,NULL,NULL,NULL,1,0,'info333@t3dev.ru','2023-04-12 17:31:31',0,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(58,'master@t3dev.ru','[\"ROLE_MASTER\"]','$2y$13$9dW/3FNy5sUNR9bsTrwMXOOb1exmyOm4qL1auOqOLmDfI1.0nfYeq',0,NULL,NULL,'Mater T3dev',NULL,'+7(123) 123-1231',NULL,NULL,NULL,'3500',2,0,NULL,'2023-04-22 18:55:41',0,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3'),(59,'super@mail.ru','[\"ROLE_COMPANY\"]','$2y$13$UpLfLUzwCjfLS07B/ANaSOXWbcGhXsIAkFpUGKqOZS5X5aYI4StSW',0,NULL,NULL,'Super Master',NULL,NULL,NULL,NULL,NULL,NULL,3,1,NULL,'2023-05-06 09:21:08',0,NULL,NULL,NULL,NULL,0.1,'Super Master','11111','super@mail.ru',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(60,'mega@mail.ru','[\"ROLE_MASTER\"]','$2y$13$oyEeae5thXfCvrM0ULDvn.Vm3mhiIDlc0hDyGOxHLjGWrJndnXd5q',0,NULL,NULL,'Mega Master','2021-10-18-121500-6456211079eeb.jpg','+7(965) 751-7678','2021-10-18-121500-645621107a466.jpg','2021-10-18-121500-645621107a6e7.jpg','2021-10-18-121500-645621107a891.jpg',NULL,1,0,'mega@mail.ru','2023-05-06 09:42:39',0,NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_job_type`
--

DROP TABLE IF EXISTS `user_job_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_job_type` (
  `user_id` int(11) NOT NULL,
  `job_type_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`job_type_id`),
  KEY `IDX_EB9FC568A76ED395` (`user_id`),
  KEY `IDX_EB9FC5685FA33B08` (`job_type_id`),
  CONSTRAINT `FK_EB9FC5685FA33B08` FOREIGN KEY (`job_type_id`) REFERENCES `job_type` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_EB9FC568A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_job_type`
--

LOCK TABLES `user_job_type` WRITE;
/*!40000 ALTER TABLE `user_job_type` DISABLE KEYS */;
INSERT INTO `user_job_type` VALUES (23,1),(23,2),(23,3),(23,4),(23,5),(23,15),(25,1),(25,2),(25,3),(25,4),(25,5),(25,8),(25,9),(25,11),(25,12),(25,13),(25,14),(25,15),(25,37),(25,38),(25,39),(50,37),(50,38),(50,39),(50,42),(53,39),(54,37),(54,38),(54,39),(56,31),(56,35),(56,36),(56,39),(56,40),(56,41),(58,37),(58,39);
/*!40000 ALTER TABLE `user_job_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profession`
--

DROP TABLE IF EXISTS `user_profession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_profession` (
  `user_id` int(11) NOT NULL,
  `profession_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`profession_id`),
  KEY `IDX_1DF4CB85A76ED395` (`user_id`),
  KEY `IDX_1DF4CB85FDEF8996` (`profession_id`),
  CONSTRAINT `FK_1DF4CB85A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_1DF4CB85FDEF8996` FOREIGN KEY (`profession_id`) REFERENCES `profession` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profession`
--

LOCK TABLES `user_profession` WRITE;
/*!40000 ALTER TABLE `user_profession` DISABLE KEYS */;
INSERT INTO `user_profession` VALUES (23,3),(25,2),(25,3),(25,7),(50,7),(51,2),(51,7),(53,7),(54,7),(56,5),(56,6),(56,7),(57,6),(57,8),(58,7);
/*!40000 ALTER TABLE `user_profession` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-18 10:17:37
